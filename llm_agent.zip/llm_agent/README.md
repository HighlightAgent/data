# Harness presentation: run it locally

## Open it
1. Double-click `harness_presentation.html`. It opens in your default browser (Chrome, Safari, Edge or Firefox).
2. Press **F** for full screen, then present.

No install or server is needed. The only thing that comes from the internet is the three Google Fonts (Source Serif 4, IBM Plex Sans, IBM Plex Mono). If you're offline, the slides fall back to Georgia, Arial and Courier New.

## Keys
| Key | Action |
|---|---|
| → · Space · Enter · click | Next build step, then next slide |
| ← · Backspace | Previous slide (shown fully built) |
| Click the left 20% of the screen | Previous slide |
| Home / End | First / last slide |
| F | Full screen on/off |
| N | Speaker notes panel on/off |
| H | Hide the key hints and slide counter |

Add `#3` to the end of the address to jump straight to slide 3.

## Live demos (slides 4)
- Slide 4 loads two real, interactive pages from the `demos/` folder. Keep that folder next to the HTML file.
- Click 1: the push button appears. Press and hold it to light the bulb.
- Click 2: the Raptor engine appears. Hover it to take it apart. Use the large **Ignite / Shut down** button at the top right of the demo to fire it.
- Clicks anywhere on the two demo cards never move to the next slide. To move on, press → or click outside the cards.
- The ⤢ button opens a large view: the dark-theme engine at full size with its list of 11 assemblies (hover a name to highlight that part), or the push button at full size. Close it with ✕, Esc or →.
- Hover a part of the Raptor and its name appears in a large label at the bottom right of the demo (for example "Main chamber · 300 bar · no igniter").
- Hover a "lines of code" chip to open the real source code. Scroll with the mouse or trackpad, or press ↑ ↓ (Page Up / Page Down for big jumps). The Raptor has three tabs: build.mjs, live.js and raptor.css. Move the mouse away, or press Esc, to close it.
- After you click inside a demo, your next click on the slide only brings focus back to the deck. Click again, or press →, to move on.
- The demos come from Anatomy (github.com/wheresryan22/anatomy), MIT licence, in `demos/ANATOMY-LICENSE.txt`. The Raptor uses WebGL for the exhaust plume, so use Chrome or Edge for the best result.

## Optional: run as a local web page
Some company laptops block scripts in files opened straight from disk. If the animations don't play, serve the folder instead:

```bash
cd ~/Desktop/harness_presentation
python3 -m http.server 8000
```

Then open http://localhost:8000/harness_presentation.html

## Editing
- The easiest way to edit text, add comments, or export to PowerPoint or PDF is still the online Slides deck (Share › Export).
- This HTML file is a snapshot of that deck. Each slide is a `<section>` inside the file. You can edit text directly in any code editor (VS Code, for example) and refresh the browser.
- Step-by-step reveals are set with `data-build-in="rise 3"` (animation, then click order). A step marked `auto` plays straight after the step before it.

## Rebuilding the presentation (source folder)
`source/` holds everything the presentation is made from:
- `source/project/` — the slides exactly as they are in the online deck (`deck.json` + one HTML file per slide)
- `source/build_local.py` — turns those slides into `harness_presentation.html` (icons, live demos, code pop-ups, presenter controls)
- `source/icons.json`, `source/code_data.json` — the icons and the highlighted Anatomy source code used by the pop-ups

To rebuild after updating the files in `source/project/`:
```bash
cd ~/Desktop/harness_presentation
pip3 install pygments        # once
python3 source/build_local.py source harness_presentation.html source/icons.json
```
The online deck remains the place to edit; ask Claude to "refresh the local file" and the slide files are pulled and rebuilt for you.
