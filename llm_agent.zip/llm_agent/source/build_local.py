import json, re, html, sys, pathlib

root = pathlib.Path(sys.argv[1])
out = pathlib.Path(sys.argv[2])
icons = json.load(open(sys.argv[3]))
deck = json.load(open(root / "project/deck.json"))

def convert(src):
    def icon(m):
        name, style = m.group(1), m.group(2)
        svg = icons.get(name, icons["Star"])
        return f'<span class="xi" role="img" aria-label="{name}" style="{style}">{svg}</span>'
    src = re.sub(r'<x-icon name="([A-Za-z]+)" style="([^"]*)"></x-icon>', icon, src)

    def embed(m):
        attrs, content = m.group(1), m.group(2)
        return f'<iframe class="xe"{attrs} sandbox="allow-scripts" srcdoc="{html.escape(content, quote=True)}"></iframe>'
    src = re.sub(r'<x-embed([^>]*)>(.*?)</x-embed>', embed, src, flags=re.S)

    def connector(m):
        attrs = m.group(1)
        g = lambda k, d=None: (re.search(r'\b' + k + r'="([^"]*)"', attrs) or [None, d])[1]
        x1, y1, x2, y2 = (float(g(k, 0)) for k in ("x1", "y1", "x2", "y2"))
        st = g("style", "")
        col = (re.search(r'color:\s*([^;]+)', st) or [None, "#9aa8b8"])[1].strip()
        bw = float((re.search(r'border-width:\s*([0-9.]+)', st) or [None, "2"])[1])
        dash = ' stroke-dasharray="8 6"' if "dashed" in st else (' stroke-dasharray="2 5"' if "dotted" in st else "")
        head = g("head", "end"); bi = g("data-build-in")
        pad = 14; left, top = min(x1, x2) - pad, min(y1, y2) - pad
        w, h = abs(x2 - x1) + 2 * pad, abs(y2 - y1) + 2 * pad
        a, b, c, d = x1 - left, y1 - top, x2 - left, y2 - top
        import math
        ang = math.atan2(d - b, c - a); L = 5 + bw * 3; W = 4 + bw * 2
        def tri(px, py, an):
            bx, by = px - L * math.cos(an), py - L * math.sin(an)
            return f'<polygon points="{px:.1f},{py:.1f} {bx - W*math.sin(an):.1f},{by + W*math.cos(an):.1f} {bx + W*math.sin(an):.1f},{by - W*math.cos(an):.1f}" fill="{col}"/>'
        ec, ed = (c - L * math.cos(ang), d - L * math.sin(ang)) if head in ("end", "both") else (c, d)
        sa, sb = (a + L * math.cos(ang), b + L * math.sin(ang)) if head == "both" else (a, b)
        heads = (tri(c, d, ang) if head in ("end", "both") else "") + (tri(a, b, ang + math.pi) if head == "both" else "")
        bia = f' data-build-in="{bi}"' if bi else ""
        return (f'<svg class="xc"{bia} viewBox="0 0 {w:.0f} {h:.0f}" style="position:absolute; left:{left:.0f}px; top:{top:.0f}px; width:{w:.0f}px; height:{h:.0f}px; overflow:visible">'
                f'<line x1="{sa:.1f}" y1="{sb:.1f}" x2="{ec:.1f}" y2="{ed:.1f}" stroke="{col}" stroke-width="{bw}"{dash}/>{heads}</svg>')
    src = re.sub(r'<x-connector([^>]*)></x-connector>', connector, src)

    LIVE = [("Push button live demo", "demos/push-button.html", 650, 486),
            ("Raptor engine live demo", "demos/raptor-engine.html", 980, 1016)]
    def img(m):
        tag = m.group(0)
        for key, href, w, h in LIVE:
            if f'alt="{key}' in tag:
                style = re.search(r'style="([^"]*)"', tag).group(1)
                return f'<div class="live" data-src="{href}" data-w="{w}" data-h="{h}" style="{style}; position:relative; overflow:hidden"></div>'
        return tag
    src = re.sub(r'<img [^>]*>', img, src)
    return src

slides = [convert((root / f"project/slides/{sid}.html").read_text()) for sid in deck["order"]]
fonts = "\n".join(f'<link rel="stylesheet" href="{f["href"]}">' for f in deck["faces"].values() if "href" in f)

from pygments.formatters import HtmlFormatter
CODE_JSON = pathlib.Path(__file__).with_name("code_data.json").read_text().replace("</", "<\\/")
PYG_CSS = HtmlFormatter(style="github-dark").get_style_defs(".cp-code")
page = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
__FONTS__
<style>
  *{box-sizing:border-box;margin:0}
  html,body{height:100%;background:#05101d;overflow:hidden;font-family:'IBM Plex Sans',Arial,sans-serif}
  #viewport{position:fixed;inset:0;display:flex;align-items:center;justify-content:center}
  #stage{position:relative;width:1920px;height:1080px;transform-origin:center center;flex:none}
  #stage>section{position:absolute;inset:0;width:1920px;height:1080px;overflow:hidden;display:flex;flex-direction:column;
    opacity:0;visibility:hidden;transition:opacity .45s ease,visibility 0s linear .45s}
  #stage>section.on{opacity:1;visibility:visible;transition:opacity .45s ease}
  section div{display:flex;flex-direction:column}
  h1{font-size:96px;font-weight:600;line-height:1.1}
  h2{font-size:64px;font-weight:600;line-height:1.15}
  h3{font-size:44px;font-weight:600;line-height:1.2}
  p{font-size:32px;line-height:1.4}
  ul,ol{padding-left:1.25em}
  li{margin:.1em 0}
  a{color:inherit}
  .xi{display:inline-flex;flex:none}
  .xi svg{width:100%;height:100%;display:block}
  .xe{border:0;background:transparent;display:block}
  .live iframe{position:absolute;border:0;background:transparent;transform-origin:0 0;z-index:1}
  aside{display:none}
  .live-say{position:absolute;right:12px;bottom:12px;max-width:560px;padding:8px 16px 8px 14px;border-radius:999px;
    background:rgba(11,27,46,.9);color:#e8eef6;font:500 24px/1.25 'IBM Plex Sans',Arial,sans-serif;display:flex;flex-direction:row;gap:10px;align-items:center;
    pointer-events:none;opacity:0;transition:opacity .25s ease;z-index:4}
  .live-say.show{opacity:1}
  .live-say:before{content:"";width:10px;height:10px;border-radius:50%;background:#57d2c1;flex:none}
  .demo-ctl{position:absolute;top:12px;right:12px;display:flex;flex-direction:row;gap:10px;z-index:5}
  .dbtn{display:inline-flex;flex-direction:row;align-items:center;gap:10px;height:48px;padding:0 20px;border-radius:999px;border:1px solid #cfd8e3;
    background:#ffffff;color:#0b1b2e;font:600 22px 'IBM Plex Sans',Arial,sans-serif;cursor:pointer;box-shadow:0 4px 14px rgba(11,27,46,.12)}
  .dbtn:hover{border-color:#2442e0}
  .dbtn .lamp{width:12px;height:12px;border-radius:50%;background:#9aa8b8}
  .dbtn[data-state="armed"] .lamp{background:#ffcf6a;box-shadow:0 0 8px 2px #ffb84a88}
  .dbtn[data-state="on"] .lamp{background:#ff8a3c;box-shadow:0 0 10px 3px #ff7a2a99}
  .dbtn.icon{width:48px;padding:0;justify-content:center}
  .dbtn.icon svg{width:24px;height:24px}
  .xp{position:absolute;left:96px;top:72px;width:1728px;height:936px;display:none;flex-direction:column;background:#0b0b0b;border-radius:18px;
    box-shadow:0 30px 80px rgba(0,0,0,.45);overflow:hidden;z-index:80}
  .xp.show{display:flex}
  .xp-head{display:flex;flex-direction:row;align-items:center;gap:16px;padding:14px 22px;border-bottom:1px solid #222;flex:none}
  .xp-title{font:600 26px 'Source Serif 4',Georgia,serif;color:#e8eef6}
  .xp-hint{font:20px 'IBM Plex Sans',Arial,sans-serif;color:#8b96a5}
  .xp-close{margin-left:auto;background:#1b1b1b;color:#e8eef6;border:1px solid #333}
  .xp-body{flex:1;position:relative;overflow:hidden}
  .xp-body iframe{position:absolute;border:0;transform-origin:0 0;background:#0b0b0b}
  .code-chip{cursor:zoom-in;transition:box-shadow .2s ease}
  .code-chip:hover{box-shadow:0 0 0 3px #57d2c1}
  .cp{position:absolute;width:1100px;height:620px;top:250px;display:none;flex-direction:column;background:#0d1117;border-radius:16px;
    box-shadow:0 24px 60px rgba(11,27,46,.35),0 0 0 1px #24364d;overflow:hidden;z-index:50}
  .cp.show{display:flex}
  .cp-head{display:flex;flex-direction:row;align-items:center;gap:14px;padding:14px 20px;background:#161b22;border-bottom:1px solid #24364d;flex:none}
  .cp-head .xi{width:26px;height:26px;color:#57d2c1}
  .cp-tab{font:500 20px 'IBM Plex Mono',monospace;color:#9aa8b8;background:transparent;border:1px solid transparent;border-radius:8px;padding:6px 12px;cursor:pointer}
  .cp-tab.on{color:#e8eef6;background:#0d1117;border-color:#30363d}
  .cp-meta{margin-left:auto;font:18px 'IBM Plex Sans',Arial,sans-serif;color:#7d8590}
  .cp-body{flex:1;overflow:auto;padding:10px 0 16px;overscroll-behavior:contain}
  .cp-code{font:20px/1.5 'IBM Plex Mono',monospace;color:#e6edf3;white-space:pre;display:block}
  .cp-l{display:flex;flex-direction:row}
  .cp-n{flex:none;width:72px;text-align:right;padding-right:18px;color:#6e7681;user-select:none}
  .cp-t{flex:none;padding-right:24px}
__PYG__
  .build-hidden{opacity:0 !important}
  #notes{position:fixed;left:0;right:0;bottom:0;max-height:38vh;overflow:auto;background:rgba(11,27,46,.96);color:#e8eef6;
    font:16px/1.55 'IBM Plex Sans',Arial,sans-serif;padding:18px 28px 22px;white-space:pre-wrap;display:none;border-top:1px solid #2a3b52}
  #notes.show{display:block}
  #hud{position:fixed;right:16px;bottom:12px;font:13px 'IBM Plex Mono',monospace;color:#9aa8b8;opacity:.75;user-select:none}
  #help{position:fixed;left:16px;bottom:12px;font:13px 'IBM Plex Sans',Arial,sans-serif;color:#9aa8b8;opacity:.75}
  body.clean #hud, body.clean #help{display:none}
</style>
</head>
<body>
<div id="viewport"><div id="stage">
__SLIDES__
</div></div>
<script type="application/json" id="code-data">__CODE__</script>
<div id="notes"></div>
<div id="help">→ / Space / click: next &nbsp;·&nbsp; ←: back &nbsp;·&nbsp; F: full screen &nbsp;·&nbsp; N: notes &nbsp;·&nbsp; H: hide hints</div>
<div id="hud"></div>
<script>
(function(){
  var stage=document.getElementById('stage'), notes=document.getElementById('notes'), hud=document.getElementById('hud');
  var slides=[].slice.call(stage.querySelectorAll(':scope > section'));
  var FROM={fade:{},rise:{translate:'0 40px'},drop:{translate:'0 -40px'},left:{translate:'-80px 0'},right:{translate:'80px 0'},
            scale:{scale:'0.85'},pop:{scale:'0.6'}};
  // Build steps per slide: each click shows one group; "auto" groups follow the previous one by themselves.
  var plans=slides.map(function(s){
    var els=[].slice.call(s.querySelectorAll('[data-build-in]')).map(function(el,i){
      var p=el.getAttribute('data-build-in').trim().split(/\\s+/);
      var o=parseInt(p[1],10); return {el:el,kind:p[0],order:isNaN(o)?0:o,auto:p.indexOf('auto')>-1,i:i};
    });
    var orders={}; els.forEach(function(e){(orders[e.order]=orders[e.order]||[]).push(e);});
    var keys=Object.keys(orders).map(Number).sort(function(a,b){return a-b;});
    var steps=[]; keys.forEach(function(k){
      var g=orders[k], auto=g.every(function(e){return e.auto;});
      if(auto && steps.length){ steps[steps.length-1].push(g); } else { steps.push([g]); }
    });
    return {els:els,steps:steps};
  });
  var cur=0, step=0, timers=[];
  function animate(e,delay){
    var f=FROM[e.kind]||{}, a={opacity:0}, b={opacity:1};
    if(f.translate){a.translate=f.translate;b.translate='0 0';}
    if(f.scale){a.scale=f.scale;b.scale='1';}
    var frames=e.kind==='pop'?[a,{opacity:1,scale:'1.06'},b]:[a,b];
    var t=setTimeout(function(){
      e.el.classList.remove('build-hidden'); syncLive();
      if(e.el.animate) e.el.animate(frames,{duration:520,easing:'cubic-bezier(.2,.7,.2,1)',fill:'none'});
    },delay); timers.push(t);
  }
  function syncLive(){
    [].slice.call(stage.querySelectorAll('.live')).forEach(function(box){
      var s=box.closest('section'), b=box.closest('[data-build-in]');
      var on=s.classList.contains('on') && !(b && b.classList.contains('build-hidden')) && !box.dataset.paused;
      var f=box.querySelector('iframe');
      if(on && !f){
        var w=+box.dataset.w, h=+box.dataset.h, bw=box.clientWidth, bh=box.clientHeight, k=Math.min(bw/w,bh/h);
        f=document.createElement('iframe'); f.src=box.dataset.src; f.title='Live demo';
        f.style.width=w+'px'; f.style.height=h+'px'; f.style.left=((bw-w*k)/2)+'px'; f.style.top=((bh-h*k)/2)+'px';
        f.style.transform='scale('+k+')'; box.insertBefore(f, box.firstChild);
      } else if(!on && f){ box.removeChild(f);
        var say=box.querySelector('.live-say'); if(say){ say.classList.remove('show'); say.textContent=''; }
        var fb=box.querySelector('.fire-btn'); if(fb){ fb.setAttribute('data-state','off'); fb.querySelector('.lbl').textContent='Ignite'; } }
    });
  }
  window.addEventListener('message',function(ev){
    var d=ev.data; if(d&&typeof d.anatomyFire==='string'){
      [].slice.call(stage.querySelectorAll('.live')).forEach(function(box){
        var f=box.querySelector('iframe'); if(!f||f.contentWindow!==ev.source) return;
        var b=box.querySelector('.fire-btn'); if(!b) return;
        b.setAttribute('data-state',d.state||'off'); b.querySelector('.lbl').textContent=d.anatomyFire.charAt(0)+d.anatomyFire.slice(1).toLowerCase();
      }); return; }
    if(!d||typeof d.anatomyReadout!=='string') return;
    [].slice.call(stage.querySelectorAll('.live')).forEach(function(box){
      var f=box.querySelector('iframe'); if(!f||f.contentWindow!==ev.source) return;
      var say=box.querySelector('.live-say'); if(!say){say=document.createElement('div');say.className='live-say';box.appendChild(say);}
      var t=d.anatomyReadout; say.textContent=t?t.charAt(0).toUpperCase()+t.slice(1):''; say.classList.toggle('show',!!t);
    });
  });
  var CODE={}; try{CODE=JSON.parse(document.getElementById('code-data').textContent);}catch(e){}
  var openPop=null, popTimer=null, codeIcon=(document.querySelector('.xi[aria-label="Code"]')||{}).innerHTML||'';
  function renderFile(pop,key,i){
    var f=CODE[key][i], body=pop.querySelector('.cp-body'), code=pop.querySelector('.cp-code');
    code.innerHTML=f.html.map(function(l,n){return '<div class="cp-l"><span class="cp-n">'+(n+1)+'</span><span class="cp-t">'+(l||' ')+'</span></div>';}).join('');
    body.scrollTop=0; body.scrollLeft=0;
    [].slice.call(pop.querySelectorAll('.cp-tab')).forEach(function(t,k){t.classList.toggle('on',k===i);});
  }
  function makePop(chip,key,section){
    var pop=document.createElement('div'); pop.className='cp';
    var total=CODE[key].reduce(function(a,f){return a+f.lines;},0);
    pop.innerHTML='<div class="cp-head"><span class="xi">'+codeIcon+'</span>'+CODE[key].map(function(f,i){
      return '<button class="cp-tab" type="button">'+f.name+' · '+f.lines+'</button>';}).join('')+
      '<span class="cp-meta">'+total.toLocaleString()+' lines · scroll to read</span></div><div class="cp-body"><div class="cp-code"></div></div>';
    var r=chip.getBoundingClientRect(), sr=section.getBoundingClientRect(), k=sr.width/1920;
    var left=Math.round((r.left-sr.left)/k); pop.style.left=Math.max(128,Math.min(left-24,1792-1100))+'px';
    pop.style.top=Math.round((r.top-sr.top)/k-12-620)+'px';
    section.appendChild(pop);
    [].slice.call(pop.querySelectorAll('.cp-tab')).forEach(function(t,i){t.addEventListener('click',function(e){e.stopPropagation();renderFile(pop,key,i);});});
    pop.addEventListener('click',function(e){e.stopPropagation();});
    pop.addEventListener('mouseenter',function(){clearTimeout(popTimer);});
    pop.addEventListener('mouseleave',function(){hidePopSoon();});
    renderFile(pop,key,0); return pop;
  }
  function showPop(pop){ clearTimeout(popTimer); if(openPop&&openPop!==pop) openPop.classList.remove('show'); pop.classList.add('show'); openPop=pop; }
  function hidePopSoon(){ clearTimeout(popTimer); popTimer=setTimeout(function(){ if(openPop){openPop.classList.remove('show'); openPop=null;} },350); }
  function wireCode(){
    [].slice.call(stage.querySelectorAll('p')).forEach(function(p){
      if(!/lines of code/i.test(p.textContent)) return;
      var chip=p.parentElement, panel=p.closest('[data-build-in]')||chip, section=p.closest('section');
      var key=/raptor/i.test(panel.textContent)?'raptor':(/push button/i.test(panel.textContent)?'push':null);
      if(!key||!CODE[key]) return;
      chip.classList.add('code-chip'); var pop=null;
      chip.addEventListener('mouseenter',function(){ if(!pop) pop=makePop(chip,key,section); showPop(pop); });
      chip.addEventListener('mouseleave',hidePopSoon);
      chip.addEventListener('click',function(e){e.stopPropagation(); if(!pop) pop=makePop(chip,key,section); showPop(pop);});
    });
  }
  wireCode();
  var EXPAND_SVG='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6"/><path d="M9 21H3v-6"/><path d="M21 3l-7 7"/><path d="M3 21l7-7"/></svg>';
  var FULL={'demos/raptor-engine.html':{src:'demos/raptor-engine-full.html',w:1520,h:1016,title:'Raptor 2 rocket engine',hint:'Hover a part or a name in the list · Ignite to fire'},
            'demos/push-button.html':{src:'demos/push-button-full.html',w:1000,h:708,title:'Push button',hint:'Press and hold the cap'}};
  var openXp=null;
  function closeXp(){ if(!openXp) return; var x=openXp; openXp=null; x.el.classList.remove('show'); var f=x.el.querySelector('iframe'); if(f) f.remove();
    delete x.box.dataset.paused; syncLive(); }
  function openExpand(box){
    var section=box.closest('section'), info=FULL[box.dataset.src]; if(!info) return;
    var el=section.querySelector('.xp');
    if(!el){ el=document.createElement('div'); el.className='xp';
      el.innerHTML='<div class="xp-head"><span class="xp-title"></span><span class="xp-hint"></span><button type="button" class="dbtn xp-close">✕&nbsp; Close</button></div><div class="xp-body"></div>';
      el.addEventListener('click',function(e){e.stopPropagation();});
      el.querySelector('.xp-close').addEventListener('click',function(e){e.stopPropagation();closeXp();});
      section.appendChild(el); }
    el.querySelector('.xp-title').textContent=info.title; el.querySelector('.xp-hint').textContent=info.hint;
    box.dataset.paused='1'; syncLive();
    var body=el.querySelector('.xp-body'); el.classList.add('show');
    var bw=1728, bh=936-77, k=Math.min((bw-40)/info.w,(bh-24)/info.h);
    var f=document.createElement('iframe'); f.src=info.src; f.title=info.title;
    f.style.width=info.w+'px'; f.style.height=info.h+'px'; f.style.transform='scale('+k+')';
    f.style.left=((bw-info.w*k)/2)+'px'; f.style.top=((bh-info.h*k)/2)+'px'; body.appendChild(f);
    openXp={el:el,box:box};
  }
  [].slice.call(stage.querySelectorAll('.live')).forEach(function(box){
    var panel=box.closest('[data-build-in]')||box;
    panel.addEventListener('click',function(e){e.stopPropagation();});
    var ctl=document.createElement('div'); ctl.className='demo-ctl';
    if(/raptor/.test(box.dataset.src)){
      var fb=document.createElement('button'); fb.type='button'; fb.className='dbtn fire-btn'; fb.setAttribute('data-state','off');
      fb.innerHTML='<span class="lamp"></span><span class="lbl">Ignite</span>';
      fb.addEventListener('click',function(e){e.stopPropagation(); var f=box.querySelector('iframe'); if(f&&f.contentWindow) f.contentWindow.postMessage({anatomyCmd:'fire'},'*');});
      ctl.appendChild(fb);
    }
    var xb=document.createElement('button'); xb.type='button'; xb.className='dbtn icon'; xb.title='Expand'; xb.innerHTML=EXPAND_SVG;
    xb.addEventListener('click',function(e){e.stopPropagation(); openExpand(box);});
    ctl.appendChild(xb); box.appendChild(ctl);
  });
  function clearTimers(){timers.forEach(clearTimeout);timers=[];}
  function setSlide(n,built){
    clearTimers(); if(openPop){openPop.classList.remove('show'); openPop=null;} closeXp();
    cur=Math.max(0,Math.min(slides.length-1,n));
    slides.forEach(function(s,i){s.classList.toggle('on',i===cur);});
    var plan=plans[cur];
    plan.els.forEach(function(e){e.el.classList.toggle('build-hidden',!built);});
    step=built?plan.steps.length:0;
    syncLive();
    var aside=slides[cur].querySelector('aside'); notes.textContent=aside?aside.textContent.trim():'';
    update();
  }
  function next(){
    var plan=plans[cur];
    if(step<plan.steps.length){
      var delay=0; plan.steps[step].forEach(function(g){g.forEach(function(e){animate(e,delay);}); delay+=380;});
      step++; update();
    } else if(cur<slides.length-1){ setSlide(cur+1,false); }
  }
  function prev(){ if(cur>0) setSlide(cur-1,true); else setSlide(0,false); }
  function update(){
    var plan=plans[cur]; hud.textContent=(cur+1)+' / '+slides.length+(plan.steps.length?'  ·  build '+step+'/'+plan.steps.length:'');
    try{history.replaceState(null,'','#'+(cur+1));}catch(e){}
  }
  function fit(){
    var s=Math.min(window.innerWidth/1920,window.innerHeight/1080);
    stage.style.transform='scale('+s+')';
  }
  document.addEventListener('keydown',function(ev){
    var k=ev.key;
    if(openPop && (k==='ArrowDown'||k==='ArrowUp'||k==='PageDown'||k==='PageUp')){
      ev.preventDefault(); var b=openPop.querySelector('.cp-body'); var step=(k.indexOf('Page')===0?500:90);
      b.scrollTop+= (k==='ArrowDown'||k==='PageDown')?step:-step; return; }
    if(openPop && k==='Escape'){ openPop.classList.remove('show'); openPop=null; return; }
    if(openXp && (k==='Escape'||k==='ArrowRight'||k==='ArrowLeft'||k===' '||k==='Enter'||k==='PageDown'||k==='PageUp'||k==='Backspace')){ ev.preventDefault(); closeXp(); return; }
    if(k==='ArrowRight'||k===' '||k==='PageDown'||k==='Enter'){ev.preventDefault();next();}
    else if(k==='ArrowLeft'||k==='PageUp'||k==='Backspace'){ev.preventDefault();prev();}
    else if(k==='Home'){setSlide(0,false);}
    else if(k==='End'){setSlide(slides.length-1,true);}
    else if(k==='f'||k==='F'){ if(!document.fullscreenElement) document.documentElement.requestFullscreen&&document.documentElement.requestFullscreen(); else document.exitFullscreen(); }
    else if(k==='n'||k==='N'){notes.classList.toggle('show');}
    else if(k==='h'||k==='H'){document.body.classList.toggle('clean');}
  });
  var refocus=false; window.addEventListener('blur',function(){refocus=true;});
  document.getElementById('viewport').addEventListener('click',function(ev){
    if(refocus){refocus=false;return;} if(ev.clientX<window.innerWidth*0.2) prev(); else next(); });
  window.addEventListener('resize',fit); fit();
  var start=parseInt((location.hash||'').slice(1),10); setSlide(isNaN(start)?0:start-1,false);
})();
</script>
</body>
</html>
"""
page = page.replace("__TITLE__", html.escape(deck.get("title", "Presentation"))).replace("__FONTS__", fonts).replace("__SLIDES__", "\n".join(slides)).replace("__CODE__", CODE_JSON).replace("__PYG__", PYG_CSS)
out.write_text(page)
print(out, len(page))
